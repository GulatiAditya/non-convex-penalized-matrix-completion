import csv
import numpy as np
from matrix_completion import svt
from scipy.stats import bernoulli
from matplotlib import pyplot as plt

m = users = 943
n = items = 1682
data_file_name = "u.data" 
data = np.loadtxt(open(data_file_name,"rb"), delimiter = " ")

mask = np.zeros((m,n))
A = np.zeros((m,n))

for user, item, rating, _ in data:
	user = (int)(user)
	item = (int)(item)
	A[user-1][item-1] = rating
	# mask[user-1][item-1] = 1

mask = 1 - bernoulli.rvs(p=0.5, size=(m, n))
l= [6000]
g = [20]
for _lambda in l:
	for gamma in g:
		solution, error1 = svt(A=A,mask=mask,regularisation='MCP', _lambda = _lambda, gamma = gamma, epoch=20)
		solution, error2 = svt(A=A,mask=mask,regularisation='Soft', _lambda = _lambda, gamma = gamma, epoch=20)
		plt.plot(range(len(error1)), error1, label='MCP L:'+str(_lambda)+' g:'+str(gamma))
		plt.plot(range(len(error2)), error2, label='Soft L:'+str(_lambda)+' g:'+str(gamma))
plt.legend()
plt.show()
# solution, error3 = svt(A=A,mask=mask,regularisation='frobenius', _lambda = 0.3, epoch=20)
# solution, error4 = svt(A=A,mask=mask,regularisation='frobenius', _lambda = 0.5, epoch=20)
# solution, error2 = svt(A=A,mask=mask,regularisation='none', _lambda = 0.1, epoch=20)

# plt.plot(range(len(error3)), error3, label='Regularised 0.3')
# plt.plot(range(len(error4)), error4, label='Regularised 0.5')