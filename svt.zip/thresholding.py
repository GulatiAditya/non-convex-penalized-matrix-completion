import numpy as np
def threshold(S, thresh,_lambda, g):
    if (thresh== 'MCP'):
    	S = np.maximum(S - _lambda, 0)
    	for i in range(len(S)):
    		if (S[i]>0 and S[i]<=g*_lambda):
    			S[i] = np.sign(S[i]*(abs(S[i])-_lambda)/(1-g**-1))
    elif (thresh=='Soft'):
    	S = np.maximum(S-_lambda, 0)
    return S

def penalty(S, pen, _lambda, g):
    if (pen=='Soft'):
        return (_lambda * (np.sum(S)))
    elif (pen=='MCP'):
        for i in range(len(S)):
            if(S[i]<=_lambda*g):
                S[i] = _lambda*S[i] - ((S[i]**2)/(2*g))
            elif (S[i]>_lambda*g):
                S[i] = 0.5 * g * _lambda**2
    return np.sum(S)